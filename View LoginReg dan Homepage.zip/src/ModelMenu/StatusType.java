
package ModelMenu;

public enum StatusType {
    ONGOING, DONE, CANCEL
}


package Main;
import View.ViewLogin;

public class Main {
    public static void main(String[] args) {
        new ViewLogin();
    }
    
}

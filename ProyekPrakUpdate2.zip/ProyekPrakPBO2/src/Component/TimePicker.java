
package Component;

import Swing.RoundedComboBoxUI;
import javax.swing.*;
import java.awt.*;
import java.sql.Time;
import java.util.Calendar;


public class TimePicker extends JPanel {

    public JComboBox<String> hourCombo;
    public JComboBox<String> minuteCombo;

    public TimePicker() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        setOpaque(false);

        // Styling global
        Font font = new Font("SansSerif", Font.PLAIN, 16);
        Dimension comboSize = new Dimension(70, 36);
        Color background = Color.WHITE;
        Color border = new Color(206, 212, 218); // Bootstrap border color
        Color foreground = new Color(33, 37, 41); // Bootstrap text color

        // ComboBox Jam
        hourCombo = createComboBox(24, font, comboSize, background, border, foreground);

        // ComboBox Menit
        minuteCombo = createComboBox(60, font, comboSize, background, border, foreground);

        JLabel colon = new JLabel(":");
        colon.setFont(new Font("SansSerif", Font.BOLD, 18));
        colon.setForeground(foreground);
        colon.setPreferredSize(new Dimension(10, 36));

        add(hourCombo);
        add(colon);
        add(minuteCombo);
    }

    private JComboBox<String> createComboBox(int limit, Font font, Dimension size,
                                             Color bg, Color border, Color fg) {
        JComboBox<String> combo = new JComboBox<>();
        for (int i = 0; i < limit; i++) {
            combo.addItem(String.format("%02d", i));
        }
        combo.setFont(font);
        combo.setPreferredSize(size);
        combo.setForeground(fg);
        combo.setBackground(bg);
        combo.setUI(new RoundedComboBoxUI(border));
        return combo;
    }

    public Time getTime() {
        int hour = Integer.parseInt((String) hourCombo.getSelectedItem());
        int minute = Integer.parseInt((String) minuteCombo.getSelectedItem());

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return new Time(cal.getTimeInMillis());
    }

    public void setTime(Time time) {
        String timeStr = time.toString();  // format: HH:mm:ss
        String[] parts = timeStr.split(":");

        if (parts.length >= 2) {
            hourCombo.setSelectedItem(parts[0]);
            minuteCombo.setSelectedItem(parts[1]);
        } else {
            System.err.println("Format Time tidak valid: " + timeStr);
        }
    }
}


package Controller;

import Model.Reservasi.DAOReservasi;
import Model.Reservasi.ModelReservasi;
import Model.TemplateTable;
import ModelMenu.StatusType;
import View.ViewReservasi;
import java.awt.Color;
import java.awt.Font;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ControllerReservasi {

    private ViewReservasi viewreservasi;
    private DAOReservasi daoreservasi;
    private List<ModelReservasi> data;

    public ControllerReservasi(ViewReservasi viewreservasi) {
        this.viewreservasi = viewreservasi;
        this.daoreservasi = new DAOReservasi();
        this.data = new ArrayList<>();
    }


    public void insertData(
        Date tanggal, Time jamMulai, int durasiJam,
        String namaCustomer, String noHpCustomer,
        String tipeStudio, double hargaPerJam) {

        ModelReservasi statement = new ModelReservasi();
        statement.setTanggal(tanggal);
        statement.setJam_mulai(jamMulai);
        statement.setDurasi_jam(durasiJam);
        statement.setNama_customer(namaCustomer);
        statement.setNomor_hp_customer(noHpCustomer);
        statement.setTipe_studio(tipeStudio);
        statement.setHarga_per_jam(hargaPerJam);
        statement.setStatus(StatusType.ONGOING);

        boolean inputBerhasil = daoreservasi.insert(statement);
        if(inputBerhasil){
            JOptionPane.showMessageDialog(null, createStyledPanel("Berhasil menambahkan reservasi baru!"), "Sukses", JOptionPane.INFORMATION_MESSAGE);
            new ViewReservasi();
            viewreservasi.dispose();
        } else {
            JOptionPane.showMessageDialog(null, createStyledPanel("Terjadi Kesalahan saat menginput data"), "Input Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void showAll() {
        data = daoreservasi.getAll();

        TemplateTable<ModelReservasi> tabelReservasi = new TemplateTable<>(
            data,
            new String[]{"Tanggal", "Nama Customer", "No HP",  "Harga Per Jam", "Jenis Studio", "Jam Mulai", "Jam Selesai", "Durasi (jam)", "Total Harga"},
            (data, columnIndex) -> {
                switch (columnIndex) {
                    case 0: return data.getTanggal();
                    case 1: return data.getNama_customer();
                    case 2: return data.getNomor_hp_customer();
                    case 3: return data.getHarga_per_jam();
                    case 4: return data.getTipe_studio();
                    case 5: return data.getJam_mulai() != null ? data.getJam_mulai().toString() : "N/A";
                    case 6: return data.getJam_selesai() != null ? data.getJam_selesai().toString() : "N/A";
                    case 7: return data.getDurasi_jam();
                    case 8: return data.getTotal_harga();
                    case 9: return data.getStatus();
                    default: return null;
                }
            }
        );

        if (viewreservasi != null && viewreservasi.getTableReservasi() != null) {
            viewreservasi.getTableReservasi().setModel(tabelReservasi);
        } else {
            System.err.println("Tidak ada view untuk menampilkan data.");
        }
    }


    // Getter data
    public List<ModelReservasi> getData() {
        return data;
    }
    
    private JPanel createStyledPanel(String message) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(new Color(220, 53, 69), 2));
        JLabel label = new JLabel("<html><div style='padding:8px;font-size:12px;color:#dc3545;'>" + message + "</div></html>");
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panel.add(label);
        return panel;
    }
    
}